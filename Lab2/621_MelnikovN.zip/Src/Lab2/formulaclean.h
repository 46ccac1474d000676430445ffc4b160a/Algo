#ifndef FORMULACLEAN_H
#define FORMULACLEAN_H

#include <QString>

QString formulaClean(const QString &f);

#endif // FORMULACLEAN_H
